module.exports = {
  extends: '../../.eslintrc-with-ts-config.js',
  rules: {
    '@typescript-eslint/no-floating-promises': 'error',
  },
};
